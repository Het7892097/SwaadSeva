import Taskbar from "../components/taskbar"
import HeroHeader from "../components/heroHeader"
export default function HomePage(){

    return <div className="max-h-fit max-w-full">
        <Taskbar/>
    <HeroHeader/>
    </div>
}